package test;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import FlightBooking.booking;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SelectFlightTest {


		WebDriver driver;
		@BeforeTest
		public void setup() {

			WebDriverManager.chromedriver().setup();  // Auto setup
	        driver = new ChromeDriver(); 
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.get("https://phptravels.net/");
			driver.manage().window().maximize();
		}
		@Test
		public void verifyFlightSelection() {
			
			booking book=new booking(driver);
			book.selectflight();
			book.chooseflight();
			String actualTitle=driver.getTitle();
			Assert.assertEquals(actualTitle, "Flights Booking", "Unexpected page title!");
			book.fillForm("Rathi", "priya", "test@example.com", "123456789","WashingtonDc", "rathi", "priya", "05 May", "01", "1990", "A1234567", "test@example.com", "123456789");
			String[] statuses = book.confirmbooking("sb-itxir5994130@personal.example.com", "testpayment");
	    
	        Assert.assertEquals(statuses[0].toLowerCase(), "paid", "Payment status is incorrect!");
	        Assert.assertEquals(statuses[1].toLowerCase(), "confirmed", "Booking status is incorrect!");
			
		}
		
		@AfterTest
		 public void tearDown() {
		        if (driver != null) {
		            driver.quit();  
		            System.out.println("Browser closed successfully.");
		        }

		}
}



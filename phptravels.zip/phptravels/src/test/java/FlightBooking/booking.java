package FlightBooking;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class booking {
         WebDriver driver;
    	 public booking(WebDriver driver) {
    		 this.driver=driver;
    	 }
        public void selectflight() {
        	 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
             WebElement lahoreToDubai = wait.until(ExpectedConditions.elementToBeClickable(
                 By.xpath("//body//main//div[@class='row g-3']//div[@class='row g-3']//div[1]//a[1]")
             ));
             lahoreToDubai.click();
        
        }
    	public void chooseflight()
    	{
    		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(90));
    	        WebElement firstFlightBtn = wait.until(ExpectedConditions.elementToBeClickable(
    	            By.xpath("(//button[@type='submit' and contains(text(),'Book')])[1]") // safer than a generic button
    	        ));
    	        firstFlightBtn.click();
    	}
    	public void fillForm(String firstName, String lastName, String emailid, String phoneno,
    			String address, String fname, String lname, String dobMonth,String dobDay,String dobYear,String passportNo,String emailid1,
    			String phoneno1)
    	{
    	
			driver.findElement(By.xpath("//input[@id='p-first-name']")).sendKeys(firstName);
			driver.findElement(By.xpath("//input[@id='p-last-name']")).sendKeys(lastName);
			driver.findElement(By.xpath("//input[@id='p-email']")).sendKeys(emailid);
			driver.findElement(By.xpath("//input[@id='p-phone']")).sendKeys(phoneno);
			driver.findElement(By.xpath("//input[@id='p-address']")).sendKeys(address);
			driver.findElement(By.xpath("//input[@id='t-first-name-1']")).sendKeys(fname);
			driver.findElement(By.xpath("//input[@id='t-last-name-1']")).sendKeys(lname);
			new Select(driver.findElement(By.name("dob_month_1"))).selectByVisibleText(dobMonth);
			new Select(driver.findElement(By.name("dob_day_1"))).selectByVisibleText(dobDay);
			new Select(driver.findElement(By.name("dob_year_1"))).selectByVisibleText(dobYear);
			driver.findElement(By.xpath("//input[@id='t-passport-1']")).sendKeys(passportNo);
			driver.findElement(By.xpath("//input[@id='p-email']")).sendKeys(emailid1);
			driver.findElement(By.xpath("//input[@id='p-phone']")).sendKeys(phoneno1);
			driver.findElement(By.id("agreechb")).click();
    	}
     
    	public String[] confirmbooking(String paymentEmail, String password)
    	{
    		driver.findElement(By.xpath("//div[@class='btn-box mt-3']")).click();
    		driver.findElement(By.xpath("//button[normalize-space()='Download as PDF']")).click();
    		driver.findElement(By.xpath("//input[@id='form']")).click();
    		   WebElement paypalFrame = driver.findElement(By.xpath("//iframe[contains(@name,'paypal')]"));
    		    driver.switchTo().frame(paypalFrame);
    		    
    		    driver.findElement(By.cssSelector("div.paypal-button-label-container")).click();
    		    driver.switchTo().defaultContent();
    		    String parentWindow = driver.getWindowHandle();
    		    for (String windowHandle : driver.getWindowHandles()) {
    		        if (!windowHandle.equals(parentWindow)) {
    		            driver.switchTo().window(windowHandle);
    		            break;
    		        }
    		    }
    		    WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
    		    wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("email"))).sendKeys(paymentEmail);
    		  
    		    
    		   
    		    driver.findElement(By.id("password")).sendKeys(password);
    		    driver.findElement(By.id("btnLogin")).click();
    		    
    		   
    		    WebElement completePurchaseBtn = wait.until(ExpectedConditions.elementToBeClickable(
    		            By.xpath("//button[contains(text(),'Complete Purchase')]"))
    		    );

    		    
    		    completePurchaseBtn.click();

    		    
    		    driver.switchTo().window(parentWindow);
    		    
    		    WebDriverWait confirmationWait = new WebDriverWait(driver, Duration.ofSeconds(30));
    		    WebElement paymentStatus = confirmationWait.until(ExpectedConditions.visibilityOfElementLocated(
    		            By.xpath("//div[contains(text(),'Payment Status')]/span | //span[contains(text(),'paid')]"))
    		    );

    		    WebElement bookingStatus = driver.findElement(By.xpath("//div[contains(text(),'Booking Status')]/span"));
    		    return new String[] { 
    		    		paymentStatus.getText(), 
    		    		bookingStatus.getText() 
    		    		};
    		    
    		    

    	}
	}


